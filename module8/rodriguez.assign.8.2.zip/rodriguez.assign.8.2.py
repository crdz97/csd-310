#Carolina Rodriguez
#Assignment 8.2
#CSD-310



import mysql.connector
from mysql.connector import errorcode
from dotenv import load_dotenv
import os

# Load .env file
load_dotenv()


# Read database credentials from environment variables
db_user = os.getenv("USER")
db_password = os.getenv("PASSWORD")
db_host = os.getenv("HOST")
db_database = os.getenv("DATABASE")

# Database configuration
config = {
    "user": db_user,
    "password": db_password,
    "host": db_host,
    "database": db_database,
    "raise_on_warnings": True
}


# Function to display films with details, cursor passed to execute queries
def show_films(cursor, title):
    print(f"\n{title}")
    # SQL query to retrieve film details with inner joins, added ORDER BY since I had to reset
    query = """
    SELECT film_name AS Name,
           film_director AS Director,
           genre_name AS Genre,
           studio_name AS Studio_Name
    FROM film
    INNER JOIN genre ON film.genre_id = genre.genre_id
    INNER JOIN studio ON film.studio_id = studio.studio_id
    ORDER BY 
        CASE film_name
            WHEN 'Gladiator' THEN 1
            WHEN 'Alien' THEN 2
            WHEN 'Get Out' THEN 3
            ELSE 4
        END;
    """
    cursor.execute(query) #sends the SQL query to the database
    results = cursor.fetchall() #retrieves all results "fetchall"
    
    for row in results: #allows us to access columns by name otherwise would use [0], etc. 
        print(f"Name: {row['Name']}"), 
        print(f"Director: {row['Director']}"), 
        print(f"Genre: {row['Genre']}")
        print(f"Studio Name: {row['Studio_Name']}")
        print("" * 40)  # Separator line
try:
    db = mysql.connector.connect(**config)
    cursor = db.cursor(dictionary=True) #turns results into dictionaries to avoid tuples error

    print("\nDatabase user {} connected to MySQL on host {} with database {}\n".format(
        db_user, db_host, db_database
    ))
    input("\nPress any key to continue...")
    show_films(cursor, "=== Displaying Films with Details ===")

#  Insert a new film into the film table
    insert_film = """
    INSERT INTO film (film_name, film_director, film_releaseDate, film_runtime, studio_id, genre_id)
    VALUES (%s, %s, %s, %s, %s, %s); 
    """ #placeholder for values "%s"
    new_film_data = ("Sinister", "Scott Derrickson", "2012", 110, 2, 1)
    cursor.execute(insert_film, new_film_data)
    db.commit()  # Commit the transaction to save changes
    show_films(cursor, "=== Displaying Films with Details After Insert ===")    

#   Update genre of "Alien" to Horror (adjust genre_id accordingly)
    update_genre = """
    UPDATE film
    SET genre_id = %s
    WHERE film_name = %s;
    """
    cursor.execute(update_genre, (1, "Alien")) #1 is Horror genre_id
    db.commit()  
    show_films(cursor, "=== Updating Alien to Horror ===")

#   Delete Gladiator
    delete_film = """
    DELETE FROM film
    WHERE film_name = %s;
    """
    cursor.execute(delete_film, ("Gladiator",))
    db.commit()
    show_films(cursor, "=== Deleting Gladiator ===")

except mysql.connector.Error as err:
    # Handle database errors
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("The supplied username or password are invalid.")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("The specified database does not exist.")
    else:
        print(err)

finally:
    # Close connection
        db.close()
        print("\nConnection closed.")
